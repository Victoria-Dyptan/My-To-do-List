package com.example.mytodolist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.example.mytodolist.Adapter.Task;
import com.example.mytodolist.Adapter.TaskAdapter;
import com.example.mytodolist.Adapter.TaskDAO;
import com.example.mytodolist.Adapter.TaskDatabase;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity  {
    Intent i;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    static TaskAdapter adapter;
    private static TaskDatabase db;

  public CardView cardall, cardwork, cardpersonal, cardeduc, cardlist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView data=findViewById(R.id.data_info);
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy      HH:mm ");
        String currentDateandTime = sdf.format(new Date());
        data.setText("Data e orario : "+currentDateandTime);
        cardall=findViewById(R.id.alltasks);
        cardwork=findViewById(R.id.work);
        cardeduc=findViewById(R.id.education);
        cardlist=findViewById(R.id.list);
        cardpersonal=findViewById(R.id.personal);








        // ADAPTER  e  DATA BASE DICHIARAZIONE----------------------------------------------------------

        db = Room.databaseBuilder(getApplicationContext(),
                TaskDatabase.class, "my_database").allowMainThreadQueries().build();

        TaskDAO taskDAO= db.taskDAO();
        adapter = new TaskAdapter(db.taskDAO().getTask(), this);




        // FAB---------------
        FloatingActionButton fab = findViewById(R.id.fabmain);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createDialog();
                // Aggiorno Lista
                adapter.notifyDataSetChanged();

            }
        });
      //WORK-----------------
        cardwork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i=new Intent(view.getContext(), CardActivity.class);

                i.putExtra("AMBITO","WORK");
                startActivity(i);
            }
        });
        //ALL---------------
        cardall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i=new Intent(view.getContext(), CardActivity.class);
                startActivity(i);

            }
        });
        //EDUC------------------
        cardeduc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i=new Intent(view.getContext(), CardActivity.class);

                i.putExtra("AMBITO", "EDUCAZIONE");
                startActivity(i);
            }
        });
        //LIST----------------
        cardlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i=new Intent(view.getContext(), Spesa.class);
                startActivity(i);

            }
        });
        //PERSONALE-----------------
        cardpersonal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i=new Intent(view.getContext(), CardActivity.class);

                i.putExtra("AMBITO","PERSONALE");
                startActivity(i);
            }
        });

         // CONTO LA QUANTITA TOTALE DELLE NUOTE
        String numero=taskDAO.countalltask();
        TextView alltask=findViewById(R.id.created);
        alltask.setText("Task totali: "+numero);

       // CONTO LA QUANTITA DELLE NOTE COMPLETATE
        TextView complet=findViewById(R.id.done);
        complet.setText("Task da completare: "+taskDAO.countcomplettedtask());


        TextView countpersonal=findViewById(R.id.count_personal);
        if(Integer.parseInt(taskDAO.countpersonale())>0) {
            countpersonal.setText(taskDAO.countpersonale());
        }
        TextView countlavoro=findViewById(R.id.count_work);

        if(Integer.parseInt(taskDAO.countlavoro())>0) {
            countlavoro.setText(taskDAO.countlavoro());
        }


        TextView counteducazione=findViewById(R.id.count_educ);

        if(Integer.parseInt(taskDAO.counteducazione())>0) {
            counteducazione.setText(taskDAO.counteducazione());
        }


        TextView countspesa=findViewById(R.id.count_list);
        if(Integer.parseInt(taskDAO.countspesa())>0) {
            countspesa.setText(taskDAO.countspesa());
        }

    }

    private void createDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

        LayoutInflater inflater = MainActivity.this.getLayoutInflater();
        View dialogView = (inflater.inflate(R.layout.dialogo_task, null));

        EditText et_data = dialogView.findViewById(R.id.datainizio);
        EditText et_titolo = dialogView.findViewById(R.id.nomep_insert);
        EditText et_contenuto = dialogView.findViewById(R.id.quantita_insert);
        Spinner et_ambito = dialogView.findViewById(R.id.ambito);
        Switch et_completato = dialogView.findViewById(R.id.completato_task);


        et_data.setOnClickListener(new View.OnClickListener() {

            // PER DATA SETTO UN ONCLICK PER CHIAMARE DATEPICKERFRAGMENT
            //-----------NON FUNZIONA--------------------
            @Override
            public void onClick(View view) {

                createDatePicker(et_data); //chiamo la mia funzione
            }
            //-------------------------------------------
        });
        builder.setView(dialogView)
                .setPositiveButton("Inserisci", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // DICHIARAZIONE DATI
                        String titolo, contenuto, datainizio, ambito;
                        boolean complet;

                        titolo = et_titolo.getText().toString();

                        contenuto = et_contenuto.getText().toString();


                        datainizio = et_data.getText().toString();


                        if (et_completato.isChecked()) {
                            complet = true;
                        } else complet = false;


                        ambito = et_ambito.getSelectedItem().toString();

                        // CREO TASK PER ADD NELLA LISTA E DB
                        Task task = new Task(titolo, contenuto, datainizio, ambito, complet);
                        db.taskDAO().insertAll(task);
                        // aggiungo task nella mia lista
                        adapter.addTask(task);
                        adapter.notifyDataSetChanged();
                    }
                })
                .setNegativeButton("Annulla", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                })
                .create().show();
    }
    // funzione che chiama e visualizza il datapicker (passiamo il nostro edit text)
    private void createDatePicker(EditText etData) {
        final Calendar cldr = Calendar.getInstance();
        int day = cldr.get(Calendar.DAY_OF_MONTH);
        int month = cldr.get(Calendar.MONTH);
        int year = cldr.get(Calendar.YEAR);
        // date picker dialog
        DatePickerDialog picker = new DatePickerDialog(MainActivity.this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        etData.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                    }
                }, year, month, day);
        picker.show();
    }


}