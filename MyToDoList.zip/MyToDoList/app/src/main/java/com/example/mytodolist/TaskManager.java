package com.example.mytodolist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.TextView;

import com.example.mytodolist.Adapter.Task;

public class TaskManager extends AppCompatActivity {
    public   static  String EXTRA_TITOLO="EXTRA_TITOLO";
    public   static  String EXTRA_CONTENUTO="EXTRA_CONTENUTO";
    public  static  String EXTRA_DATAINIZIO="EXTRA_DATAINIZIO";
    public  static  String EXTRA_AMBITO="EXTRA_AMBITO";
    public   static  String EXTRA_COMPLETATO="EXTRA_COMPLETATO";
    public static String EXTRA_SERIA="EXTRA_SERIA";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_manager);
        TextView titolo =findViewById(R.id.titolo_ins);
        TextView contenuto =findViewById(R.id.contenuto_ins);
        Switch completato = findViewById(R.id.completato_ins);
        TextView datainizio = findViewById(R.id.datainizio_ins);
        TextView ambito = findViewById(R.id.ambito_ins);


        Intent intent = getIntent();
        // RECUPERO  OGGETTO
        Task nota=(Task) intent.getSerializableExtra("EXTRA_SERIA");


        titolo.setText(nota.getTitolo());
        contenuto.setText(nota.getContenuto());
        completato.setChecked(nota.isCompletato());
        datainizio.setText(nota.getDatainserimento());
        ambito.setText(nota.getAmbito());

    }
}