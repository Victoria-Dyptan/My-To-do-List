package com.example.mytodolist;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;


import com.example.mytodolist.Adapter.TaskDatabase;
import com.example.mytodolist.AdapterSpesa.Prodotti;
import com.example.mytodolist.AdapterSpesa.ProdottiAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Spesa extends AppCompatActivity {
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    static ProdottiAdapter adapter;
    private SwipeRefreshLayout swipeRefreshLayout;
    private static TaskDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spesa);

        recyclerView=findViewById(R.id.rec_view);
        // nuovo layoutManager
        layoutManager=new LinearLayoutManager(this);

        recyclerView.setLayoutManager(layoutManager);



        db =  Room.databaseBuilder(getApplicationContext(),
                TaskDatabase.class, "my_database").allowMainThreadQueries().build();

        adapter = new ProdottiAdapter(db.taskDAO().getProdotti(), this);
        recyclerView.setAdapter(adapter);



// FAB---------------
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment dialog= new Spesa.AddProdottoDialogFragment();
                // VISUALIZZO LA DIALOG PER INSERIRE UN NUOVO TASK
                dialog.show(getSupportFragmentManager(), "AddProdotto");
                // Aggiorno Lista
                adapter.notifyDataSetChanged();

            }
        });
    }


// AGGIUNGERE UNA NOTA-------------------------------------------------------------

    public static class AddProdottoDialogFragment extends DialogFragment {


        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
            AlertDialog.Builder alertDialog= new AlertDialog.Builder(getActivity());
            LayoutInflater inflater=requireActivity().getLayoutInflater();
            alertDialog.setView(inflater.inflate(R.layout.dialogo_spesa,null));

            //------POSITIVE BUTTON----------------------
            alertDialog.setPositiveButton("Inserisci", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    // DICHIARAZIONE DATI
                    String nomeprodotto;
                          int  quantita;


                    EditText et_nome=getDialog().findViewById(R.id.nomep_insert);
                   nomeprodotto=et_nome.getText().toString();

                    EditText et_quantita=getDialog().findViewById(R.id.quantita_insert);
                    quantita=Integer.parseInt(et_quantita.getText().toString());


                    // CREO TASK PER ADD NELLA LISTA E DB
                    Prodotti prodotto=new Prodotti(nomeprodotto,quantita);
                    db.taskDAO().insertAll(prodotto);
                    // aggiungo task nella mia lista
                    adapter.addProdotto(prodotto);

                }
            });


            //------------------NEGATIVE BUTTON-----------------------------
            alertDialog.setNegativeButton("Anulla", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            });
            return alertDialog.create();
        }

    }
    // FINE DIALOG---------------------------


}



