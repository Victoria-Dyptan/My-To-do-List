package com.example.mytodolist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import com.example.mytodolist.Adapter.Task;
import com.example.mytodolist.Adapter.TaskAdapter;
import com.example.mytodolist.Adapter.TaskDatabase;

import java.util.ArrayList;
import java.util.List;

public class CardActivity extends AppCompatActivity {


    // CLASS DATA PICKER FRAGMENT-------------------------------------




    //  DICHIARAZIONE-------------------------
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    static TaskAdapter adapter;
    private SwipeRefreshLayout swipeRefreshLayout;
    private static TaskDatabase db;
    SharedPreferences sharedPref; // mio sharedPreferences


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);
        //associamo il rec_view
        recyclerView = findViewById(R.id.rec_view);
        // nuovo layoutManager
        layoutManager = new LinearLayoutManager(this);

        recyclerView.setLayoutManager(layoutManager);
        String ambito = getIntent().getStringExtra("AMBITO");


        // ADAPTER  e  DATA BASE DICHIARAZIONE----------------------------------------------------------

        db = Room.databaseBuilder(getApplicationContext(),
                TaskDatabase.class, "my_database").allowMainThreadQueries().build();
        if(ambito!= null){
            adapter = new TaskAdapter(db.taskDAO().getNota(ambito), this);

        }
        else {
            adapter = new TaskAdapter(db.taskDAO().getTask(), this);
        }
        recyclerView.setAdapter(adapter);

       // -----------------REFRESH------------------------------
        swipeRefreshLayout=findViewById(R.id.swiperefresh);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                aggiornaRecycleView(); // metodo a parte
            }
        });




    }
    // FINE DIALOG---------------------------
    private void aggiornaRecycleView() {  // METODO PER AGGIORNARE LA RECYCLEVIEW
        adapter.clear();
        List l=db.taskDAO().getTask();
        adapter.addAll((ArrayList<Task>) l);
        Toast toast=Toast. makeText(getApplicationContext(),"HAI PROVATO DI AGGIORNARE",Toast. LENGTH_SHORT);
        swipeRefreshLayout.setRefreshing(false);
    }

}


