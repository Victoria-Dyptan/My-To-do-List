package com.example.mytodolist.Adapter;


import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.mytodolist.AdapterSpesa.Prodotti;

@Database(entities = {Task.class, Prodotti.class}, version = 1)
public abstract class TaskDatabase extends RoomDatabase {
    public abstract TaskDAO taskDAO();}