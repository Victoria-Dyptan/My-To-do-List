package com.example.mytodolist.AdapterSpesa;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "spesa_task")
public class Prodotti implements Serializable {
    @PrimaryKey(autoGenerate = true)
    int id;
    @ColumnInfo(name="nomeprodotto")
    private String nomeprodotto;

    public Prodotti(String nomeprodotto, int quantita) {
        this.nomeprodotto = nomeprodotto;
        this.quantita = quantita;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomeprodotto() {
        return nomeprodotto;
    }

    public void setNomeprodotto(String nomeprodotto) {
        this.nomeprodotto = nomeprodotto;
    }

    public int getQuantita() {
        return quantita;
    }

    public void setQuantita(int quantita) {
        this.quantita = quantita;
    }

    @ColumnInfo(name="quantita")
    private int quantita;


}
