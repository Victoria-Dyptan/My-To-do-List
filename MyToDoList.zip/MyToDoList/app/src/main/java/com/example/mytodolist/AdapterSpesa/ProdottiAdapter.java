package com.example.mytodolist.AdapterSpesa;


import static com.example.mytodolist.TaskManager.EXTRA_SERIA;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.example.mytodolist.Adapter.TaskDAO;
import com.example.mytodolist.Adapter.TaskDatabase;
import com.example.mytodolist.R;
import com.example.mytodolist.TaskManager;

import java.util.ArrayList;
import java.util.List;

public class ProdottiAdapter extends RecyclerView.Adapter<ProdottiAdapter.ViewHolder> {
    private List<Prodotti> lista;
    private AppCompatActivity activity;

// COSTRUTTOTE
    public ProdottiAdapter(List<Prodotti> task, AppCompatActivity activity) {
        this.lista = (ArrayList <Prodotti>)task;
        this.activity = activity;
    }
 // ADD TASK NELLA LISTA
    public void addProdotto(Prodotti task)
    {
        this.lista.add(task);
        notifyDataSetChanged();
    }

    // CANCELLA DALLA LISTA-----------------------
public void removeProdotto(int position){
        this.lista.remove(position);
        notifyDataSetChanged();
     }

// PULISCI TUTTA LA LISTA
    public void clear() {
        this.lista.clear();
        notifyDataSetChanged();
    }

    // Add a list of items -- change to type used
    public void addAll(ArrayList<Prodotti> list) {
        lista.addAll(list);
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.prodotti_riga,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.nomeprodotto.setText(lista.get(position).getNomeprodotto());
        holder.quantita.setText(String.valueOf(lista.get(position).getQuantita()));


        // Pulsante per cancellare il task
        holder.cancella.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               TaskDatabase db =  Room.databaseBuilder(holder.nomeprodotto.getContext(),
                       TaskDatabase.class, "my_database").allowMainThreadQueries().build();
                TaskDAO prodottiDAO= db.taskDAO();
                // cancello dal room database
                prodottiDAO.deletebyidprodotto(lista.get(holder.getAdapterPosition()).getId());
                // cancello dalla recycleview
                lista.remove(holder.getAdapterPosition());
                // aggiorno lista
                notifyDataSetChanged();
            }
        });


        // ---------------cambiato
        Prodotti task = lista.get(position);

        // SE CLICCO SULLA RIGA UTILIZZA INTENT
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
         /*      Intent intent = new Intent(activity.getApplicationContext(), TaskManager.class); //DEVO CAMBIARE LA SECONDA ACTIVITY
                // ABBIAMO PASSATO UN INTERO OGGETTO DI TIPO INSEGNAMENTO-------------------------
                 intent.putExtra(EXTRA_SERIA, task);
                activity.startActivity(intent);*/
            }
        });
    }


    @Override
    public int getItemCount() {
        return lista.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView nomeprodotto, quantita;
        Button cancella;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nomeprodotto=itemView.findViewById(R.id.nomeprodotto);
            quantita=itemView.findViewById(R.id.quantita);
           cancella=itemView.findViewById(R.id.cancella);

        }
    }
}
