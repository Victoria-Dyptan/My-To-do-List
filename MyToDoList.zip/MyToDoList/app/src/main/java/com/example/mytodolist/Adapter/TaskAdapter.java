package com.example.mytodolist.Adapter;


import static com.example.mytodolist.TaskManager.EXTRA_SERIA;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.example.mytodolist.R;
import com.example.mytodolist.TaskManager;


import java.util.ArrayList;
import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.ViewHolder> {
    private List<Task> lista;
    private AppCompatActivity activity;

// COSTRUTTOTE
    public TaskAdapter(List<Task> task, AppCompatActivity activity) {
        this.lista = (ArrayList <Task>)task;
        this.activity = activity;

    }
 // ADD TASK NELLA LISTA
    public void addTask(Task task)
    {
        this.lista.add(task);
        notifyDataSetChanged();
    }

    // CANCELLA DALLA LISTA-----------------------
public void removeTask(int position){
        this.lista.remove(position);
        notifyDataSetChanged();
     }

// PULISCI TUTTA LA LISTA
    public void clear() {
        this.lista.clear();
        notifyDataSetChanged();
    }

    // Add a list of items -- change to type used
    public void addAll(ArrayList<Task> list) {
        lista.addAll(list);
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_riga,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.titolo.setText(lista.get(position).getTitolo());
        holder.descrizione.setText(lista.get(position).getContenuto());
        holder.completato.setChecked(lista.get(position).isCompletato());

        holder.completato.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                TaskDatabase db =  Room.databaseBuilder(holder.titolo.getContext(),
                        TaskDatabase.class, "my_database").allowMainThreadQueries().build();
                TaskDAO taskDAO= db.taskDAO();
                db.taskDAO().update_singletask(b,lista.get(holder.getAdapterPosition()).getId());
            }
        });
        // Pulsante per cancellare il task
        holder.cancella.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TaskDatabase db =  Room.databaseBuilder(holder.titolo.getContext(),
                        TaskDatabase.class, "my_database").allowMainThreadQueries().build();
                TaskDAO taskDAO= db.taskDAO();
                // cancello dal room database
                taskDAO.deletebyid(lista.get(holder.getAdapterPosition()).getId());
                // cancello dalla recycleview
                lista.remove(holder.getAdapterPosition());
                // aggiorno lista
                notifyDataSetChanged();
            }
        });


        // ---------------cambiato
        Task task = lista.get(position);

        // SE CLICCO SULLA RIGA UTILIZZA INTENT
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity.getApplicationContext(), TaskManager.class); //DEVO CAMBIARE LA SECONDA ACTIVITY
                // ABBIAMO PASSATO UN INTERO OGETTO DI TIPO INSEGNAMENTO-------------------------
                 intent.putExtra(EXTRA_SERIA, task);
                activity.startActivity(intent);
            }
        });
    }


    @Override
    public int getItemCount() {
        return lista.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView titolo, descrizione;
        Switch completato;
        Button cancella;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            titolo=itemView.findViewById(R.id.titolo_task);
            descrizione=itemView.findViewById(R.id.descrizione);
            completato=itemView.findViewById(R.id.completato_task);
            cancella=itemView.findViewById(R.id.detele_btn);

        }
    }
}
