package com.example.mytodolist.Adapter;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.mytodolist.AdapterSpesa.Prodotti;

import java.util.List;

@Dao
public interface TaskDAO {
    // recupero tuttal la lista
    @Query("SELECT * FROM table_task")
    List<Task> getTask();

   // recupero la lista con un determinato ambito
    @Query("SELECT * FROM table_task WHERE ambito=:ambito")
    List<Task> getNota(String ambito);

  // cancelazione dalla lista di un task
    @Query("DELETE FROM table_task WHERE id= :id")
    void deletebyid(int id);

    @Insert
    void insertAll(Task ... tasks);

    @Delete
    void delete(Task user);


    @Update
    void update(Task tasks);


    // count di tutti i task
   @Query("SELECT COUNT (*) FROM table_task")
     String countalltask();
   // count dei task completati
    @Query("SELECT COUNT (*) FROM table_task WHERE completato=1")
    String countcomplettedtask();


    @Query("SELECT COUNT (*) FROM table_task WHERE ambito='WORK'")
    String countlavoro();
    @Query("SELECT COUNT (*) FROM table_task WHERE ambito='EDUCAZIONE'")
    String counteducazione();
    @Query("SELECT COUNT (*) FROM table_task WHERE ambito='PERSONALE'")
    String countpersonale();

    @Query("SELECT COUNT (*) FROM spesa_task")
    String countspesa();

    // aggiornamento di un singolo task
    @Query("UPDATE table_task SET completato = :completato WHERE id =:id")
    void update_singletask(boolean completato, int id);

    //---------------------------------- SPESA TASK--------------


    @Query("SELECT * FROM spesa_task")
    List<Prodotti> getProdotti();
    // cancellazione del prodotto
    @Query("DELETE FROM spesa_task WHERE id= :id")
    void deletebyidprodotto(int id);

    @Insert
    void insertAll(Prodotti... tasks);

    @Delete
    void delete(Prodotti user);


    @Update
    void update(Prodotti tasks);

}