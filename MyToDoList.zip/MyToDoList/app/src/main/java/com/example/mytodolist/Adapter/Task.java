package com.example.mytodolist.Adapter;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;
@Entity(tableName = "table_task")
public class Task implements Serializable {
    @PrimaryKey(autoGenerate = true)
    int id;
    @ColumnInfo(name="titolo")
    private String titolo;
    @ColumnInfo(name="contenuto")
    private String contenuto;

    public int getId() {
        return id;
    }

    @ColumnInfo(name="datainserimento")
    private String datainserimento;
    @ColumnInfo(name="ambito")
    private String ambito;
    @ColumnInfo(name="completato")
    private boolean completato;

    public Task(String titolo, String contenuto, String datainserimento,String ambito, boolean completato) {
        this.titolo = titolo;
        this.contenuto = contenuto;
        this.datainserimento = datainserimento;
        this.completato = completato;
        this.ambito=ambito;
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public String getContenuto() {
        return contenuto;
    }

    public void setContenuto(String contenuto) {
        this.contenuto = contenuto;
    }

    public String getDatainserimento() {
        return datainserimento;
    }

    public void setDatainserimento(String datainserimento) {
        this.datainserimento = datainserimento;
    }

    public boolean isCompletato() {
        return completato;
    }

    public void setCompletato(boolean completato) {
        this.completato = completato;
    }

    public String getAmbito() {
        return ambito;
    }

    public void setAmbito(String ambito) {
        this.ambito = ambito;
    }

}
